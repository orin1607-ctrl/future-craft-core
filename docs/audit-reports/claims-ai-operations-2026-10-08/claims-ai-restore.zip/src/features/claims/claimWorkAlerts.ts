/** Claim-row work alerts + customer-request helpers. Reuses existing tasks / followups / notifications. No new tables. */

import { STATUS_MANUAL, type ClaimRecord } from './claimsConstants';
import { customerTableLabel } from './customerRequestModel';

export const CUSTOMER_REQUEST_KINDS: Array<{ key: string; label: string }> = [
  { key: 'send_doc', label: 'בקשת מסמך חסר' },
  { key: 'complete_form', label: 'השלמת טופס' },
  { key: 'sign_doc', label: 'חתימה על מסמך' },
  { key: 'affidavit', label: 'תצהיר' },
  { key: 'schedule_surveyor', label: 'תיאום שמאי' },
  { key: 'present_car', label: 'להעמיד רכב לבדיקה' },
  { key: 'contact', label: 'ליצור קשר' },
  { key: 'free', label: 'בקשה חופשית' },
  { key: 'other', label: 'פעולה אחרת' },
];

export const CUSTOMER_REQUEST_STATUSES: Array<{ key: string; label: string }> = [
  { key: 'pending', label: 'ממתין' },
  { key: 'sent', label: 'נשלח' },
  { key: 'received', label: 'התקבל — לבדיקה' },
  { key: 'done', label: 'בוצע' },
  { key: 'cancelled', label: 'בוטל' },
];

export type ClaimAlert = { key: string; label: string; tone: 'need' | 'wait' | 'info'; mailIds?: string[]; count?: number; taskId?: string; why?: string };

function isTreatTask(t: { treatmentItem?: string; kind?: string }) {
  return t.treatmentItem === 'true' || t.kind === 'treatment_item';
}

export function isMailTableAlertOn(t: { tableAlert?: string; done?: string }) {
  return t.done !== 'true' && t.tableAlert !== 'off';
}

export function customerKindLabel(key: string) {
  return CUSTOMER_REQUEST_KINDS.find((x) => x.key === key)?.label || key || 'בקשה ללקוח';
}

export function customerStatusLabel(key: string) {
  return CUSTOMER_REQUEST_STATUSES.find((x) => x.key === key)?.label || key || 'ממתין';
}

export function customerStatusOf(t: ClaimRecord): string {
  if (t.audience !== 'customer') return '';
  if (t.customerStatus) return t.customerStatus;
  if (t.done === 'true') return 'done';
  return 'pending';
}

export function isOpenCustomerTask(t: ClaimRecord): boolean {
  if (t.audience !== 'customer') return false;
  const st = customerStatusOf(t);
  return st === 'pending' || st === 'sent' || st === 'received';
}

export type MailRequestKind = 'doc' | 'sign' | 'generic' | 'info' | 'reply' | 'update' | 'approve' | 'reject' | 'other';
export type DetectedMailRequest = { type: string; label: string; kind: MailRequestKind };

const REQUEST_TYPES: Array<{ re: RegExp; type: string; label: string }> = [
  { re: /אי[\s-]?הגשת|אי הגשת תביעה/, type: 'no_claim_form', label: 'טופס אי-הגשת תביעה' },
  { re: /רישיון נהיגה/, type: 'driver_license', label: 'רישיון נהיגה' },
  { re: /רישיון רכב/, type: 'vehicle_license', label: 'רישיון רכב' },
  { re: /הודעה על תאונה|טופס אירוע/, type: 'accident_notice', label: 'טופס הודעה על תאונה' },
  { re: /עותק.{0,12}פוליסה|פוליסת הביטוח|(?:נא |חסר.{0,12}|העביר.{0,18}|צרף.{0,18}|השלמ.{0,18})פוליסה/, type: 'policy', label: 'פוליסה' },
  { re: /אישור משטרה/, type: 'police', label: 'אישור משטרה' },
  { re: /דוח שמאי|שמאות/, type: 'surveyor_report', label: 'דוח שמאי' },
  { re: /חשבונית מוסך|חשבונית/, type: 'garage_invoice', label: 'חשבונית מוסך' },
  { re: /תמונ(?:ות|ה) נזק/, type: 'damage_photos', label: 'תמונות נזק' },
];

const INTENT_TYPES: Array<{ re: RegExp; type: string; label: string; kind: MailRequestKind }> = [
  { re: /נא למסור|נבקש לדעת|נדרש מידע|פרטים נוספים|נא לעדכן אותנו/, type: 'info', label: 'בקשת מידע', kind: 'info' },
  { re: /נא להגיב|נבקש תגובה|נא לאשר קבלה|נדרשת תגובה|ממתינים לתשובתכם/, type: 'reply', label: 'בקשת תגובה', kind: 'reply' },
  { re: /עדכון סטטוס|סטטוס התיק|נעדכן כי|התיק עבר לסטטוס/, type: 'update', label: 'עדכון', kind: 'update' },
  { re: /אושרה התביעה|אישור תשלום|אושר לשלם|אושרה לתשלום/, type: 'approve', label: 'אישור', kind: 'approve' },
  { re: /נדחתה התביעה|דחיית התביעה|התביעה נדחתה|לא אושרה התביעה/, type: 'reject', label: 'דחייה', kind: 'reject' },
  { re: /נא לטפל|יש לטפל בפנייה|נדרש טיפול בתיק/, type: 'other', label: 'טיפול אחר', kind: 'other' },
];

function requestHay(text: string) {
  return String(text || '')
    .split(/כמפורט בתקנון החברה|PERSONAL_MAIL_NR/)[0]
    .slice(0, 2500);
}

export function isDocMailRequest(kind: string) {
  return kind === 'doc' || kind === 'sign' || kind === 'generic';
}

export function detectMailRequests(text: string): DetectedMailRequest[] {
  const hay = requestHay(text);
  const out: DetectedMailRequest[] = [];
  const sign = /לחתום|חתום על|ולהחזיר|החזרה חתומ/;
  for (const req of REQUEST_TYPES) {
    if (req.re.test(hay)) out.push({ type: req.type, label: req.label, kind: sign.test(hay) ? 'sign' : 'doc' });
  }
  if (!out.length && sign.test(hay)) {
    out.push({ type: 'sign_return', label: 'לחתום ולהחזיר את המסמך המצורף', kind: 'sign' });
  }
  if (!out.some((x) => isDocMailRequest(x.kind)) && /השלמת מסמכים|מסמכים חסרים|נא להעביר|נא לצרף|אודה להשלמת|חוסרים/.test(hay)) {
    out.push({ type: 'docs_generic', label: 'השלמת מסמכים לפי הבקשה במייל', kind: 'generic' });
  }
  for (const req of INTENT_TYPES) {
    if (req.re.test(hay) && !out.some((x) => x.type === req.type)) out.push({ type: req.type, label: req.label, kind: req.kind });
  }
  return out;
}

export function mailLooksInbound(fromAddr: string, ownMailbox: string) {
  const from = String(fromAddr || '').toLowerCase();
  const own = String(ownMailbox || '').toLowerCase();
  if (!from) return true;
  return !own || !from.includes(own);
}

/** Show treatment on imported mail: real inbound, or a document request even when From is our mailbox (self TEST). */
export function mailShowsTreatment(fromAddr: string, ownMailbox: string, text: string) {
  if (mailLooksInbound(fromAddr, ownMailbox)) return true;
  return detectMailRequests(text).length > 0;
}

export type AlertContext = {
  tasks: ClaimRecord[];
  notifs: ClaimRecord[];
  gmailPending: Array<Record<string, unknown>>;
  scheduledFollowups: Array<{ id?: string; claim_id: string; status?: string; purpose?: string; mail_kind?: string }>;
  garageReviews?: Record<string, { review_status?: string }>;
};

export function isScheduledOnceMail(purpose?: string) {
  return purpose === 'scheduled_send';
}

export function isRecurringMailFollowup(f: { mail_kind?: string; purpose?: string }) {
  return f.mail_kind === 'email_repeat' || f.purpose === 'recurring_send';
}

export function mailActionLabel(count: number) {
  if (count <= 0) return '';
  if (count === 1) return 'מייל חדש';
  return `${count} מיילים דורשים טיפול`;
}

export function shortStatusNote(s: string, max = 48) {
  const t = String(s || '').replace(/\s+/g, ' ').trim();
  if (!t) return '';
  return t.length > max ? `${t.slice(0, max - 1)}…` : t;
}

function isDocsOrderCopy(s: string) {
  const t = String(s || '').replace(/\s+/g, ' ').trim();
  return !t ? false : t === 'תיק ישן / דורש סידור מסמכים' || t.includes('תיק ישן') || t === 'תיק מסודר';
}

/** Table/list text for last treatment. Does not reuse סטטוס טיפול / lastStatusNote. */
export function lastTreatmentActionText(c: { lastTreatmentAction?: string; lastStatusNote?: string; lastTreatmentAt?: string }) {
  const action = String(c.lastTreatmentAction || '').replace(/\s+/g, ' ').trim();
  if (action && !isDocsOrderCopy(action)) return action;
  return '';
}

const GENERIC_TREATMENT_ACTIONS = new Set([
  'עדכון טיפול',
  'טיפול',
  'טיפול נסגר',
  'טיפול הושלם',
  'טופל — אין המשך',
]);

function oneLine(s: string | undefined) {
  return String(s || '').replace(/\s+/g, ' ').trim();
}

/** Status-change history must not copy the existing סטטוס טיפול sentence. */
export function statusChangeHistoryNote(prevNote?: string, nextNote?: string) {
  const prev = oneLine(prevNote);
  const next = oneLine(nextNote);
  if (!next || next === prev) return '';
  return next;
}

/** One write for עדכון טיפול: user text → lastStatusNote only. */
export function treatmentUpdatePersist(payload: {
  action?: string;
  note?: string;
  manualNote?: string;
  statusChoice?: string;
  closed?: boolean;
  existingLastStatusNote?: string;
}): { lastStatusNote: string; lastTreatmentAction: string } {
  const manual = oneLine(payload.manualNote);
  const note = oneLine(payload.note);
  const action = oneLine(payload.action);
  const typed = payload.statusChoice === STATUS_MANUAL && manual
    ? manual
    : note || (payload.closed || GENERIC_TREATMENT_ACTIONS.has(action) ? '' : action);
  return {
    lastStatusNote: typed || oneLine(payload.existingLastStatusNote),
    lastTreatmentAction: payload.closed ? 'טיפול הושלם' : 'עדכון טיפול',
  };
}

export function untreatedMailIds(c: ClaimRecord, ctx: AlertContext): string[] {
  const dismissed = new Set(
    ctx.tasks
      .filter((t) => t.claimId === c.id && t.gmailMessageId && t.tableAlert === 'off' && !isTreatTask(t))
      .map((t) => String(t.gmailMessageId)),
  );
  const fromTasks = ctx.tasks
    .filter((t) => t.claimId === c.id && t.gmailMessageId && isMailTableAlertOn(t) && !isTreatTask(t))
    .map((t) => String(t.gmailMessageId));
  const fromNotifs = ctx.notifs
    .filter((n) => n.claimId === c.id && n.read !== 'true' && (n.type === 'gmail_auto' || n.type === 'gmail_review'))
    .map((n) => String(n.gmail_message_id || n.gmailMessageId || ''))
    .filter(Boolean);
  return [...new Set([...fromTasks, ...fromNotifs].filter((id) => !dismissed.has(id)))];
}

export function countUntreatedMails(c: ClaimRecord, ctx: AlertContext): number {
  return untreatedMailIds(c, ctx).length;
}

/** Opening/reading a mail is not completion. Missing/awaiting docs cannot be marked done. */
export function canMarkMailTaskDone(task: { docState?: string }, nextStatus: string): { ok: boolean; reason: string } {
  if (nextStatus === 'doc_not_needed') return { ok: true, reason: '' };
  if (nextStatus !== 'done') return { ok: true, reason: '' };
  if (task.docState === 'missing' || task.docState === 'awaiting_signature') {
    return { ok: false, reason: 'חסר מסמך — לא ניתן לסמן הושלם עד שהמסמך קיים או עד שמסמנים ״אין צורך במסמך״' };
  }
  return { ok: true, reason: '' };
}

export function buildClaimRowAlerts(c: ClaimRecord, ctx: AlertContext): ClaimAlert[] {
  const out: ClaimAlert[] = [];
  const add = (key: string, label: string, tone: ClaimAlert['tone'], extra?: Pick<ClaimAlert, 'mailIds' | 'count' | 'taskId' | 'why'>) => {
    if (!out.some((x) => x.key === key)) out.push({ key, label, tone, ...extra });
  };

  const claimTasks = ctx.tasks.filter((t) => t.claimId === c.id);
  const pendingAssigned = ctx.gmailPending.some((p) => String(p.assigned_claim_id || '') === c.id && !p.imported_at);
  const untreated = untreatedMailIds(c, ctx);
  const openCust = claimTasks.filter(isOpenCustomerTask);

  const openTreats = claimTasks.filter((t) => isTreatTask(t) && t.done !== 'true' && t.workStatus !== 'done');
  for (const t of openTreats) {
    const name = t.action || 'טיפול';
    const treatLabel = t.replyReceived === 'true'
      ? `מייל חדש — ${name}`
      : (t.workStatus === 'doc_received' || t.docState === 'ready')
        ? `התקבל — לבדיקה: ${name}`
        : (t.workStatus === 'waiting_doc' || t.docState === 'missing')
          ? `חסר: ${name}`
          : name;
    add(`treat_${t.id}`, treatLabel || name, t.replyReceived === 'true' || t.workStatus === 'doc_received' ? 'need' : 'wait', {
      taskId: t.id,
      mailIds: t.gmailMessageId ? [t.gmailMessageId] : undefined,
      why: `טיפול פתוח: ${name}`,
    });
  }
  if (untreated.length) {
    add('mail_action', mailActionLabel(untreated.length), 'need', {
      mailIds: untreated,
      count: untreated.length,
      why: untreated.length === 1 ? 'מייל חדש ששויך לתיק ועדיין דורש תשומת לב' : `${untreated.length} מיילים חדשים שעדיין דורשים תשומת לב`,
    });
  } else if (pendingAssigned) {
    add('new_mail', 'מייל חדש', 'need', { why: 'מייל שויך לתיק וממתין לייבוא' });
  }
  for (const t of openCust) {
    const label = customerTableLabel(t);
    if (!label) continue;
    const st = customerStatusOf(t);
    add(`cust_${t.id}`, label, st === 'received' ? 'need' : 'wait', {
      taskId: t.id,
      why: st === 'received' ? 'הלקוח החזיר — ממתין לאישור ידני' : 'בקשה פתוחה ללקוח',
    });
  }

  if (ctx.garageReviews?.[c.id]?.review_status === 'awaiting_review') {
    add('garage_review', 'התקבל — לבדיקה', 'need', {
      why: 'צילומי מוסך התקבלו וממתינים לבדיקה',
    });
  }

  return out;
}

export function customerTaskHistoryAction(prev: ClaimRecord | null, next: ClaimRecord): { action: string; note: string } {
  const kind = customerKindLabel(next.customerKind || next.action || '');
  const text = next.requestText || next.note || '';
  const who = next.createdBy || next.owner || '';
  if (!prev) {
    return {
      action: next.audience === 'customer' ? 'משימה ללקוח נוצרה' : `משימה נוספה: ${next.action || ''}`,
      note: [kind, text, next.channel ? `ערוץ: ${next.channel}` : '', next.scheduledAt ? `תזמון: ${next.scheduledAt}` : '', who ? `נוצר ע״י: ${who}` : ''].filter(Boolean).join(' · '),
    };
  }
  const prevSt = customerStatusOf(prev) || (prev.done === 'true' ? 'done' : 'pending');
  const nextSt = customerStatusOf(next) || (next.done === 'true' ? 'done' : 'pending');
  if (prevSt !== nextSt) {
    const map: Record<string, string> = {
      sent: 'משימה נשלחה',
      received: 'התקבל מהלקוח — לבדיקה',
      done: 'טיפול הושלם',
      cancelled: 'סטטוס השתנה',
      pending: 'סטטוס השתנה',
    };
    return {
      action: next.audience === 'customer' ? (map[nextSt] || 'סטטוס השתנה') : (next.done === 'true' ? `משימה הושלמה: ${next.action || ''}` : `משימה עודכנה: ${next.action || ''}`),
      note: `סטטוס: ${customerStatusLabel(prevSt)} → ${customerStatusLabel(nextSt)}${text ? ` · ${text}` : ''}`,
    };
  }
  return {
    action: next.audience === 'customer' ? 'משימה ללקוח עודכנה' : `משימה עודכנה: ${next.action || ''}`,
    note: text,
  };
}

export function inferRecipientKind(mailTo: string, claim: { clientEmail?: string; insEmail?: string; insRepEmail?: string } | null, stored?: string) {
  const to = String(mailTo || '').trim().toLowerCase();
  const client = String(claim?.clientEmail || '').trim().toLowerCase();
  const ins = String(claim?.insEmail || '').trim().toLowerCase();
  const rep = String(claim?.insRepEmail || '').trim().toLowerCase();
  if (stored === 'client' || stored === 'insurer' || stored === 'other') return stored;
  if (to && client && to === client) return 'client';
  if (to && ((ins && to === ins) || (rep && to === rep))) return 'insurer';
  return 'other';
}

export function recipientKindLabel(kind: string) {
  if (kind === 'client') return 'לקוח';
  if (kind === 'insurer') return 'חברת הביטוח';
  return 'נמען אחר';
}

export const FOLLOWUP_DAY_PRESETS = [3, 4, 5, 7] as const;
export type FollowupDayPreset = (typeof FOLLOWUP_DAY_PRESETS)[number] | 'other';
export const RECURRING_DAY_PRESETS = [1, 2, 3] as const;
export type RecurringDayPreset = (typeof RECURRING_DAY_PRESETS)[number] | 'other';

export function normalizeFollowupDays(n: unknown): number {
  const v = Math.round(Number(n));
  if (!Number.isFinite(v) || v < 1) return 3;
  return Math.min(30, v);
}

export function followupDaysPreset(n: unknown): FollowupDayPreset {
  const d = normalizeFollowupDays(n);
  return (FOLLOWUP_DAY_PRESETS as readonly number[]).includes(d) ? (d as (typeof FOLLOWUP_DAY_PRESETS)[number]) : 'other';
}

export function normalizeRecurringDays(n: unknown): number {
  const v = Math.round(Number(n));
  if (!Number.isFinite(v) || v < 1) return 1;
  return Math.min(30, v);
}

export function recurringDaysPreset(n: unknown): RecurringDayPreset {
  const d = normalizeRecurringDays(n);
  return (RECURRING_DAY_PRESETS as readonly number[]).includes(d) ? (d as (typeof RECURRING_DAY_PRESETS)[number]) : 'other';
}

export function recurringLabel(n: unknown): string {
  const d = normalizeRecurringDays(n);
  if (d === 1) return 'כל יום';
  if (d === 2) return 'כל יומיים';
  return `כל ${d} ימים`;
}

export type RecurringFirstSendMode = 'now' | 'later';

export function parseLocalDateTime(date: string, time: string): Date | null {
  if (!date || !time) return null;
  const d = new Date(`${date}T${time}`);
  if (Number.isNaN(d.getTime())) return null;
  return d;
}

export function addRecurringDays(base: Date, days: unknown): Date {
  return new Date(base.getTime() + normalizeRecurringDays(days) * 86_400_000);
}

export function defaultRecurringFirstLocal(nowMs = Date.now()): { date: string; time: string } {
  const d = new Date(nowMs + 86_400_000);
  const pad = (n: number) => String(n).padStart(2, '0');
  return {
    date: `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`,
    time: '10:00',
  };
}

export function resolveRecurringFirstRun(opts: {
  mode: RecurringFirstSendMode;
  date?: string;
  time?: string;
  datetimeLocal?: string;
  nowMs?: number;
  allowPast?: boolean;
}): { ok: true; firstAt: Date; sendNow: boolean } | { ok: false; error: string } {
  const nowMs = opts.nowMs ?? Date.now();
  if (opts.mode === 'now') {
    return { ok: true, firstAt: new Date(nowMs - 15_000), sendNow: true };
  }
  const fromParts = parseLocalDateTime(opts.date || '', opts.time || '');
  const fromLocal = opts.datetimeLocal ? new Date(opts.datetimeLocal) : null;
  const first = fromParts || (fromLocal && !Number.isNaN(fromLocal.getTime()) ? fromLocal : null);
  if (!first) return { ok: false, error: 'נא לבחור תאריך ושעה לשליחה הראשונה' };
  if (!opts.allowPast && first.getTime() < nowMs - 30_000) {
    return { ok: false, error: 'מועד השליחה הראשונה חייב להיות בעתיד' };
  }
  return { ok: true, firstAt: first, sendNow: false };
}

export function recurringFirstPlannedAt(
  jobs: Array<{ planned_at?: string }>,
  fallback?: string,
): string {
  const times = jobs
    .map((j) => Date.parse(j.planned_at || ''))
    .filter((n) => Number.isFinite(n));
  if (!times.length) return fallback || '';
  return new Date(Math.min(...times)).toISOString();
}

export function followupWaitDaysFromRow(row: {
  wait_days?: string;
  repeat_every_days?: string;
  next_run_at?: string;
  created_at?: string;
}): number {
  if (row.wait_days) return normalizeFollowupDays(row.wait_days);
  if (row.repeat_every_days) return normalizeFollowupDays(row.repeat_every_days);
  const start = Date.parse(String(row.created_at || ''));
  const due = Date.parse(String(row.next_run_at || ''));
  if (Number.isFinite(start) && Number.isFinite(due) && due > start) {
    return normalizeFollowupDays(due / 86400000 - start / 86400000);
  }
  return 3;
}
